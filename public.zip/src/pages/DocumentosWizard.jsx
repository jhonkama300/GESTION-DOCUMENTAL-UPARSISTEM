import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button } from 'primereact/button'
import { Dropdown } from 'primereact/dropdown'
import { Tag } from 'primereact/tag'
import { Toast } from 'primereact/toast'
import { Steps } from 'primereact/steps'
import PageHeader from '../components/PageHeader.jsx'
import EmptyState from '../components/EmptyState.jsx'
import RequisitoField from '../components/admin/RequisitoField.jsx'
import { plantillasAdminService } from '../services/admin.plantillas.service.js'
import { empleadosService } from '../services/empleados.service.js'
import { contratosService } from '../services/contratos.service.js'
import { entidadesService } from '../services/entidades.service.js'
import { documentsService } from '../services/documents.service.js'
import { useEntidad } from '../context/EntidadContext.jsx'

/**
 * DocumentosWizard — ITERACIÓN 6 · Motor Documental Visual
 *
 * Wizard UNIVERSAL para generar CUALQUIER documento del motor.
 * Funciona idéntico para contratos, certificaciones, cartas, memorandos,
 * actas, otrosíes, etc. — porque la UI renderiza DINÁMICAMENTE según
 * el requirements del backend.
 *
 * Pasos:
 *   1. Seleccionar plantilla (de cualquier tipo_documento)
 *   2. Llenar contexto (empleado/contrato/entidad) según lo que pida
 *   3. Llenar inputs manuales (los declara el backend)
 *   4. Vista previa + generar
 *
 * PRINCIPIO: el frontend NO SABE qué pedir. Pregunta al backend via
 * `requirements` y renderiza lo que dice.
 */

const STEPS = [
  { label: 'Plantilla' },
  { label: 'Contexto' },
  { label: 'Datos manuales' },
  { label: 'Vista previa' },
]

export default function DocumentosWizard() {
  const navigate = useNavigate()
  const { currentEntidad } = useEntidad()
  const toast = useRef(null)

  // ── Estado del wizard
  const [step, setStep] = useState(0)
  const [plantilla, setPlantilla] = useState(null)     // plantilla seleccionada (objeto de listTemplates)
  const [requirements, setRequirements] = useState(null)  // respuesta de GET /requirements
  const [context, setContext] = useState({})             // { empleadoId, contratoId, entidadId }
  const [manual, setManual] = useState({})                // { NOMBRE: 'valor', ... }

  // ── Estado de catálogos
  const [plantillas, setPlantillas] = useState([])
  const [empleados, setEmpleados] = useState([])
  const [contratos, setContratos] = useState([])
  const [entidades, setEntidades] = useState([])

  // ── Estado de carga
  const [loadingPlantillas, setLoadingPlantillas] = useState(false)
  const [loadingRequirements, setLoadingRequirements] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [result, setResult] = useState(null)              // respuesta del backend al generar

  // ── Carga inicial: plantillas + catálogos
  useEffect(() => {
    const load = async () => {
      setLoadingPlantillas(true)
      try {
        const data = await plantillasAdminService.list()
        setPlantillas(data.plantillas || [])
      } catch (err) {
        toast.current?.show({
          severity: 'error',
          summary: 'Error',
          detail: err.message,
          life: 5000,
        })
      } finally {
        setLoadingPlantillas(false)
      }

      try {
        const [emps, ents] = await Promise.all([
          empleadosService.list().catch(() => ({ empleados: [] })),
          entidadesService.list().catch(() => ({ entidades: [] })),
        ])
        setEmpleados(emps.empleados || [])
        setEntidades(ents.entidades || [])
      } catch {
        // Silenciar
      }
    }
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ── Cuando carga empleado en contexto, cargar sus contratos
  useEffect(() => {
    if (!context.empleadoId) {
      setContratos([])
      return
    }
    const load = async () => {
      try {
        const data = await contratosService.list({ empleadoId: context.empleadoId })
        setContratos(data.contratos || [])
      } catch {
        setContratos([])
      }
    }
    load()
  }, [context.empleadoId])

  // ── Cuando se selecciona plantilla, cargar requirements
  useEffect(() => {
    if (!plantilla) {
      setRequirements(null)
      return
    }
    const load = async () => {
      setLoadingRequirements(true)
      try {
        // La plantilla del wizard viene de plantillasAdminService.list(), cuyo id es numérico
        const adminList = await plantillasAdminService.list()
        const adminRow = (adminList.plantillas || []).find((p) => p.id === plantilla.id)
        if (!adminRow) {
          throw new Error(`No se encontró la plantilla "${plantilla.id}" en el admin`)
        }
        const reqs = await plantillasAdminService.getVariables(adminRow.id)
        // getVariables retorna { plantilla, version, variables, total_detected, total_configured, total_pending }
        // Lo convertimos a requirements via local builder
        const built = buildRequirementsFromVariables(reqs)
        setRequirements(built)
      } catch (err) {
        toast.current?.show({
          severity: 'error',
          summary: 'Error',
          detail: err.response?.data?.error?.message || err.message,
          life: 5000,
        })
        setRequirements(null)
      } finally {
        setLoadingRequirements(false)
      }
    }
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plantilla])

  // ── Pre-seleccionar la entidad actual cuando se carga
  useEffect(() => {
    if (currentEntidad && entidades.length > 0) {
      // Mapeo aproximado sede_id → entidad_id
      // (sede_id 1 = Uparsistem = entidad 1, sede_id 2 = Jeanpiaget = entidad 2)
      // Es un mapeo 1:1 actual. Cuando empleados.sede_id migre a entidad_id,
      // este fallback se quita.
      const ent = entidades.find((e) => e.id === currentEntidad.id)
      if (ent && !context.entidadId) {
        setContext((c) => ({ ...c, entidadId: ent.id }))
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entidades, currentEntidad])

  // ── Validaciones de cada paso
  const canNext = useMemo(() => {
    if (step === 0) return !!plantilla
    if (step === 1) {
      if (!requirements) return false
      if (requirements.needs.empleado && !context.empleadoId) return false
      if (requirements.needs.contrato && !context.contratoId) return false
      if (requirements.needs.entidad && !context.entidadId) return false
      return true
    }
    if (step === 2) {
      if (!requirements) return false
      // Todos los obligatorios manuales llenos
      for (const r of requirements.manual_inputs) {
        if (r.obligatorio && !manual[r.variable]) return false
      }
      return true
    }
    return true
  }, [step, plantilla, requirements, context, manual])

  // ── Generar documento
  const handleGenerate = async () => {
    if (!plantilla || !requirements) return
    setGenerating(true)
    setResult(null)
    try {
      const payload = documentsService.buildPayload(
        plantilla.id,
        {
          empleadoId: context.empleadoId || null,
          contratoId: context.contratoId || null,
          entidadId:  context.entidadId  || null,
        },
        manual,
      )
      const data = await documentsService.generate(payload)
      setResult(data)
      setStep(4)
      toast.current?.show({
        severity: 'success',
        summary: 'Documento generado',
        detail: `ID #${data.id} · ${data.replaced ?? 0} variables reemplazadas`,
        life: 4000,
      })
    } catch (err) {
      toast.current?.show({
        severity: 'error',
        summary: 'Error al generar',
        detail: err.response?.data?.error?.message || err.message,
        life: 5000,
      })
    } finally {
      setGenerating(false)
    }
  }

  const handleReset = () => {
    setStep(0)
    setPlantilla(null)
    setRequirements(null)
    setContext({})
    setManual({})
    setResult(null)
  }

  return (
    <div>
      <Toast ref={toast} />

      <PageHeader
        icon="pi-file-edit"
        title="Generar documento"
        subtitle="Wizard universal del motor. Funciona con CUALQUIER plantilla."
        actions={
          step > 0 ? (
            <Button
              label="Reiniciar"
              icon="pi pi-refresh"
              outlined
              size="small"
              onClick={handleReset}
            />
          ) : null
        }
      />

      <div className="card p-3 mb-4">
        <Steps
          model={STEPS}
          activeIndex={step}
          onSelect={(e) => setStep(e.index)}
          readOnly={generating}
          className="text-xs"
        />
      </div>

      {/* ── Paso 0: Plantilla */}
      {step === 0 && (
        <StepPlantilla
          plantillas={plantillas}
          loading={loadingPlantillas}
          selected={plantilla}
          onSelect={setPlantilla}
        />
      )}

      {/* ── Paso 1: Contexto */}
      {step === 1 && (
        <StepContexto
          requirements={requirements}
          loading={loadingRequirements}
          context={context}
          setContext={setContext}
          empleados={empleados}
          contratos={contratos}
          entidades={entidades}
        />
      )}

      {/* ── Paso 2: Datos manuales */}
      {step === 2 && (
        <StepManuales
          requirements={requirements}
          manual={manual}
          setManual={setManual}
        />
      )}

      {/* ── Paso 3: Vista previa */}
      {step === 3 && (
        <StepPreview
          plantilla={plantilla}
          requirements={requirements}
          context={context}
          manual={manual}
          generating={generating}
          onGenerate={handleGenerate}
        />
      )}

      {/* ── Paso 4: Resultado */}
      {step === 4 && result && (
        <StepResultado
          result={result}
          plantilla={plantilla}
          onReset={handleReset}
          onVolver={() => navigate('/dashboard')}
        />
      )}

      {/* ── Footer con navegación */}
      {step < 4 && (
        <div className="flex justify-between pt-3 mt-3 border-t border-slate-200 dark:border-slate-700">
          <Button
            label="Atrás"
            icon="pi pi-arrow-left"
            outlined
            size="small"
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0 || generating}
          />
          {step < 3 ? (
            <Button
              label="Siguiente"
              icon="pi pi-arrow-right"
              iconPos="right"
              severity="info"
              size="small"
              onClick={() => setStep((s) => Math.min(3, s + 1))}
              disabled={!canNext}
            />
          ) : (
            <Button
              label={generating ? 'Generando…' : 'Generar documento'}
              icon={generating ? 'pi pi-spin pi-spinner' : 'pi pi-send'}
              severity="success"
              size="small"
              onClick={handleGenerate}
              disabled={generating}
            />
          )}
        </div>
      )}
    </div>
  )
}

// ── Pasos

function StepPlantilla({ plantillas, loading, selected, onSelect }) {
  if (loading) {
    return <div className="card p-12 text-center text-slate-400"><i className="pi pi-spin pi-spinner text-2xl" /></div>
  }

  return (
    <div>
      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
        Elegí la plantilla con la que querés generar un documento. El sistema
        va a detectar automáticamente qué datos te pide.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {plantillas.map((p) => (
          <button
            key={p.id}
            onClick={() => onSelect(p)}
            className={`text-left p-4 rounded-lg border-2 transition-all ${
              selected?.id === p.id
                ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/20'
                : 'border-slate-200 dark:border-slate-700 hover:border-brand-300'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-violet-700 text-white flex items-center justify-center shrink-0">
                <i className="pi pi-file-word" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">
                  {p.nombre}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {p.tipo_documento || 'documento'} · {p.categoria || 'General'}
                </p>
                {p.version_activa && (
                  <p className="text-[10px] text-slate-400 mt-0.5">v{p.version_activa} activa</p>
                )}
              </div>
              {selected?.id === p.id && <i className="pi pi-check-circle text-brand-600" />}
            </div>
          </button>
        ))}
      </div>
      {plantillas.length === 0 && (
        <EmptyState
          icon="pi-inbox"
          title="No hay plantillas"
          description="El admin aún no ha creado plantillas. Pedile a un Administrador que vaya a /admin/plantillas."
        />
      )}
    </div>
  )
}

function StepContexto({
  requirements, loading, context, setContext, empleados, contratos, entidades,
}) {
  if (loading) {
    return <div className="card p-12 text-center text-slate-400"><i className="pi pi-spin pi-spinner text-2xl" /></div>
  }
  if (!requirements) {
    return <EmptyState icon="pi-exclamation-triangle" title="Sin requirements" description="No se pudo cargar la configuración de la plantilla." />
  }

  const inputs = requirements.context_inputs || []
  const fields = inputs.length > 0
    ? inputs
    : [{ source: '_none', label: 'Esta plantilla no requiere contexto', endpoint: null }]

  return (
    <div>
      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
        Elegí los datos de contexto que la plantilla necesita.
      </p>
      <div className="card p-5 space-y-4">
        {fields.map((ci) => {
          if (ci.source === 'empleado') {
            return (
              <div key="empleado">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">
                  Empleado <span className="text-rose-500">*</span>
                </label>
                <Dropdown
                  value={context.empleadoId ?? null}
                  options={empleados.map((e) => ({ value: e.id, label: e.nombre }))}
                  onChange={(e) => setContext((c) => ({ ...c, empleadoId: e.value, contratoId: null }))}
                  placeholder="Seleccionar empleado"
                  className="w-full"
                  filter
                />
              </div>
            )
          }
          if (ci.source === 'contrato') {
            return (
              <div key="contrato">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">
                  Contrato {!context.empleadoId && <span className="text-[10px] text-slate-400">(elegí empleado primero)</span>}
                  {context.empleadoId && <span className="text-rose-500">*</span>}
                </label>
                <Dropdown
                  value={context.contratoId ?? null}
                  options={contratos.map((c) => ({
                    value: c.id,
                    label: `${c.tipo} · ${c.fecha_inicio} → ${c.fecha_fin || 'indef.'} · $${(c.salario || 0).toLocaleString('es-CO')}`,
                  }))}
                  onChange={(e) => setContext((c) => ({ ...c, contratoId: e.value }))}
                  placeholder={context.empleadoId ? 'Seleccionar contrato' : 'Esperando empleado…'}
                  className="w-full"
                  disabled={!context.empleadoId}
                />
                {context.empleadoId && contratos.length === 0 && (
                  <p className="text-[10px] text-amber-600 dark:text-amber-400 mt-1">
                    Este empleado no tiene contratos registrados. Crealo en /admin/contratos.
                  </p>
                )}
              </div>
            )
          }
          if (ci.source === 'entidad') {
            return (
              <div key="entidad">
                <label className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5 block">
                  Entidad empleadora <span className="text-rose-500">*</span>
                </label>
                <Dropdown
                  value={context.entidadId ?? null}
                  options={entidades.map((e) => ({ value: e.id, label: `${e.nombre} (${e.nit || 's/NIT'})` }))}
                  onChange={(e) => setContext((c) => ({ ...c, entidadId: e.value }))}
                  placeholder="Seleccionar entidad"
                  className="w-full"
                  filter
                />
              </div>
            )
          }
          return null
        })}

        {/* Si NO hay context_inputs (caso plantillas sin contexto) */}
        {inputs.length === 0 && (
          <p className="text-sm text-slate-500 dark:text-slate-400 italic text-center py-2">
            <i className="pi pi-info-circle mr-1" />
            Esta plantilla no requiere contexto. Avanzá a "Datos manuales".
          </p>
        )}
      </div>
    </div>
  )
}

function StepManuales({ requirements, manual, setManual }) {
  if (!requirements) return null
  const inputs = requirements.manual_inputs || []
  const constants = requirements.constants || []

  if (inputs.length === 0) {
    return (
      <EmptyState
        icon="pi-check"
        title="Sin inputs manuales"
        description="Esta plantilla no tiene variables manuales que completar. Avanzá al paso final."
      />
    )
  }

  return (
    <div>
      <p className="text-sm text-slate-600 dark:text-slate-400 mb-3">
        Completá los datos manuales que la plantilla necesita.
      </p>
      {constants.length > 0 && (
        <div className="card p-3 mb-3 bg-slate-50 dark:bg-slate-800/30">
          <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 mb-2">
            <i className="pi pi-lock mr-1" />Valores fijos (no se editan)
          </p>
          <div className="flex flex-wrap gap-2">
            {constants.map((c) => (
              <Tag key={c.variable} value={`${c.variable} = ${c.valor}`} severity="secondary" />
            ))}
          </div>
        </div>
      )}
      <div className="card p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
        {inputs.map((req) => (
          <RequisitoField
            key={req.variable}
            requisito={req}
            value={manual[req.variable]}
            onChange={(val) => setManual((m) => ({ ...m, [req.variable]: val }))}
          />
        ))}
      </div>
    </div>
  )
}

function StepPreview({ plantilla, requirements, context, manual, generating }) {
  return (
    <div className="space-y-3">
      <p className="text-sm text-slate-600 dark:text-slate-400">
        Revisá el resumen y generá el documento. El motor declarativo usará
        esta información para resolver todas las variables.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Summary
          icon="pi-file-word"
          label="Plantilla"
          value={plantilla?.nombre || '—'}
        />
        <Summary icon="pi-list" label="Variables detectadas" value={`${requirements?.total_variables ?? 0} (config: ${requirements?.total_manual ?? 0} manual, ${requirements?.total_constants ?? 0} constante)`} />
        {context.empleadoId && <Summary icon="pi-user" label="Empleado" value={context.empleadoId} />}
        {context.contratoId && <Summary icon="pi-file-edit" label="Contrato" value={context.contratoId} />}
        {context.entidadId  && <Summary icon="pi-building" label="Entidad"  value={context.entidadId} />}
        {Object.entries(manual).filter(([, v]) => v !== '' && v != null).map(([k, v]) => (
          <Summary key={k} icon="pi-pencil" label={k} value={String(v)} />
        ))}
      </div>

      {generating && (
        <div className="card p-6 text-center text-slate-500">
          <i className="pi pi-spin pi-spinner text-3xl mb-2" />
          <p className="text-sm">El motor declarativo está generando tu documento…</p>
        </div>
      )}
    </div>
  )
}

function StepResultado({ result, onReset, onVolver, plantilla }) {
  const downloadUrl = result.docxUrl
  return (
    <div className="text-center py-8 animate-fade-in">
      <div className="w-20 h-20 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mb-4">
        <i className="pi pi-check text-4xl text-emerald-600" />
      </div>
      <h3 className="text-2xl font-semibold text-slate-800 dark:text-slate-100">¡Documento generado!</h3>
      <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto">
        El motor declaró <strong>{plantilla?.nombre}</strong> usando la configuración
        declarativa. Se generaron {result.replaced ?? 0} reemplazos.
      </p>
      <div className="mt-6 max-w-md mx-auto bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4 text-left space-y-2">
        <Row label="ID" value={`#${result.id}`} />
        <Row label="Hash" value={result.hash} mono />
        {result.unresolved?.length > 0 && (
          <Row
            label="Sin resolver"
            value={result.unresolved.join(', ')}
            warn
          />
        )}
      </div>
      <div className="flex gap-2 justify-center mt-6">
        {downloadUrl && (
          <Button
            label="Descargar DOCX"
            icon="pi pi-download"
            severity="info"
            onClick={() => window.open(downloadUrl, '_blank')}
          />
        )}
        <Button label="Generar otro" icon="pi pi-refresh" outlined onClick={onReset} />
        <Button label="Volver al dashboard" icon="pi pi-home" outlined onClick={onVolver} />
      </div>
    </div>
  )
}

// ── Helpers UI

function Summary({ icon, label, value }) {
  return (
    <div className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/50">
      <i className={`pi ${icon} text-slate-400`} />
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-wider text-slate-500">{label}</p>
        <p className="text-sm font-medium text-slate-800 dark:text-slate-100 truncate">{value}</p>
      </div>
    </div>
  )
}

function Row({ label, value, mono, warn }) {
  return (
    <div className="flex items-center justify-between gap-2 text-xs">
      <span className="text-slate-500 dark:text-slate-400">{label}</span>
      <span className={`${mono ? 'font-mono text-[10px]' : 'font-medium'} ${warn ? 'text-amber-600 dark:text-amber-400' : 'text-slate-800 dark:text-slate-100'} truncate`}>
        {value}
      </span>
    </div>
  )
}

/**
 * Construye un shape `requirements` a partir de la respuesta de
 * `GET /api/admin/plantillas/{id}/variables` (la fuente real de la config).
 *
 * Reutiliza la lógica del `RequirementsService` backend: analiza las variables
 * configuradas y deduce qué contexto se necesita, qué inputs manuales
 * pedir, y qué constantes mostrar.
 */
function buildRequirementsFromVariables(data) {
  const variables = data.variables || []

  const needs = { empleado: false, contrato: false, entidad: false, usuario: false, sistema: false }
  const context_inputs = []
  const manual_inputs = []
  const constants = []
  const compound = []

  for (const v of variables) {
    if (v.status !== 'configured' || !v.config) continue
    const c = v.config
    switch (c.origen) {
      case 'empleado':
        needs.empleado = true
        if (!context_inputs.find((x) => x.source === 'empleado')) {
          context_inputs.push({ source: 'empleado', label: 'Empleado', endpoint: '/api/empleados' })
        }
        break
      case 'contrato':
        needs.contrato = true
        if (!context_inputs.find((x) => x.source === 'contrato')) {
          context_inputs.push({
            source: 'contrato', label: 'Contrato', endpoint: '/api/contratos',
            depends_on: 'empleado',
          })
        }
        break
      case 'entidad':
        needs.entidad = true
        if (!context_inputs.find((x) => x.source === 'entidad')) {
          context_inputs.push({ source: 'entidad', label: 'Entidad', endpoint: '/api/entidades' })
        }
        break
      case 'usuario':
        needs.usuario = true
        break
      case 'sistema':
        needs.sistema = true
        break
      case 'manual':
        manual_inputs.push({
          variable: v.nombre_variable,
          placeholder: c.placeholder || '',
          obligatorio: !!c.obligatorio,
          tipo_dato: c.tipo_dato || 'string',
          opciones: c.opciones || null,
        })
        break
      case 'constante':
        constants.push({ variable: v.nombre_variable, valor: c.valor_constante })
        break
      case 'compuesto':
        compound.push({ variable: v.nombre_variable, source_variable: '', function: '' })
        break
    }
  }

  return {
    plantilla: data.plantilla,
    version: data.version,
    needs,
    context_inputs,
    manual_inputs,
    constants,
    compound,
    total_variables: data.total_detected,
    total_manual: manual_inputs.length,
    total_constants: constants.length,
    total_compound: compound.length,
  }
}
