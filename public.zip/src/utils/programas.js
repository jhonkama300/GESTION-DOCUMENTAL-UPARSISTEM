// ── Cargos (posiciones de trabajo)
//     Cuando el backend tenga el proxy de ESCO, este fallback deja de ser crítico
export const CARGOS = [
  // Dirección y gerencia
  'Director General', 'Director Ejecutivo', 'Director de Área', 'Director Comercial',
  'Director Financiero', 'Director de Operaciones', 'Director de Talento Humano',
  'Director Técnico', 'Director de Proyectos', 'Director de Sistemas',
  'Director Médico', 'Director de Calidad', 'Director de Planta',
  'Gerente General', 'Gerente Comercial', 'Gerente Financiero', 'Gerente de Operaciones',
  'Gerente de Talento Humano', 'Gerente de Sistemas', 'Gerente de Proyectos',
  'Gerente Regional', 'Gerente de Sucursal', 'Gerente Comercial Junior',
  'Gerente de Planta', 'Gerente de Producción', 'Gerente de Calidad',
  'Subgerente', 'Subdirector',

  // Jefatura y coordinación
  'Jefe de Equipo', 'Jefe de Zona', 'Jefe de Producción', 'Jefe de Mantenimiento',
  'Jefe de Bodega', 'Jefe de Logística', 'Jefe de Cartera', 'Jefe de Compras',
  'Jefe de Sistemas', 'Jefe de Desarrollo', 'Jefe de Calidad',
  'Jefe de Recursos Humanos', 'Jefe de Contabilidad', 'Jefe de Tesorería',
  'Jefe de Mercadeo', 'Jefe de Ventas',
  'Coordinador', 'Coordinador Académico', 'Coordinador de Zona',
  'Coordinador de Eventos', 'Coordinador de Proyectos', 'Coordinador de Calidad',
  'Coordinador Logístico', 'Coordinador de Ventas', 'Coordinador de Nómina',
  'Coordinador de Selección', 'Coordinador de SST', 'Coordinador de Mantenimiento',

  // Análisis y consultoría
  'Analista Senior', 'Analista Junior', 'Analista de Datos', 'Analista Financiero',
  'Analista Contable', 'Analista de Riesgos', 'Analista de Crédito',
  'Analista de Compras', 'Analista de Nómina', 'Analista de Selección',
  'Analista de Capacitación', 'Analista SST', 'Analista de Calidad',
  'Analista de Mercadeo', 'Analista de Ventas', 'Analista de Cartera',
  'Analista de Sistemas', 'Analista de Soporte', 'Analista de Logística',
  'Analista Administrativo', 'Analista Jurídico', 'Analista de Proyectos',
  'Consultor', 'Consultor Senior', 'Consultor Junior',

  // Tecnología y desarrollo
  'Desarrollador Senior', 'Desarrollador Junior', 'Desarrollador Full Stack',
  'Desarrollador Frontend', 'Desarrollador Backend', 'Desarrollador Mobile',
  'Desarrollador DevOps', 'Desarrollador de Software', 'Ingeniero de Software',
  'Ingeniero de Sistemas', 'Ingeniero de Sistemas y Computación',
  'Ingeniero en Sistemas', 'Ingeniero Informático', 'Ingeniero de Cómputo',
  'Ingeniero en Computación', 'Ingeniero de Software Senior',
  'Ingeniero DevOps', 'Ingeniero de Datos', 'Ingeniero de Soporte',
  'Ingeniero de Redes', 'Ingeniero de QA', 'Ingeniero de Testing',
  'Ingeniero de Machine Learning', 'Ingeniero de IA',
  'Arquitecto de Software', 'Arquitecto Cloud', 'Arquitecto de Datos',
  'Tech Lead', 'Scrum Master', 'Product Owner', 'Engineering Manager',
  'QA Engineer', 'QA Manual', 'QA Automatizado',
  'Data Engineer', 'Data Scientist', 'Data Analyst', 'Data Engineer Senior',
  'Analista de BI', 'Analista de Datos Senior', 'Machine Learning Engineer',
  'Diseñador UX', 'Diseñador UI', 'Diseñador UX/UI',
  'Product Designer', 'Diseñador Gráfico', 'Diseñador Web',
  'Administrador de Bases de Datos', 'DBA', 'Administrador de Sistemas',
  'Administrador de Redes', 'Administrador Cloud', 'Soporte Técnico',
  'Help Desk', 'Técnico de Sistemas', 'Programador', 'Programador Senior',
  'Programador Junior', 'Programador Web', 'Frontend Developer',
  'Backend Developer', 'Full Stack Developer', 'Mobile Developer',
  'DevOps Engineer', 'Cloud Architect', 'Solutions Architect',
  'Scrum Master', 'Product Manager', 'Project Manager',

  // Ingenierías
  'Ingeniero Civil', 'Ingeniero Industrial', 'Ingeniero Mecánico',
  'Ingeniero Eléctrico', 'Ingeniero Electrónico', 'Ingeniero Electromecánico',
  'Ingeniero Mecatrónico', 'Ingeniero Químico', 'Ingeniero Ambiental',
  'Ingeniero Civil Senior', 'Ingeniero Residente', 'Ingeniero de Proyectos',
  'Ingeniero de Calidad', 'Ingeniero de Producción', 'Ingeniero de Planta',
  'Ingeniero de Mantenimiento', 'Ingeniero de Diseño',

  // Contabilidad y finanzas
  'Contador General', 'Contador Público', 'Contador Junior', 'Contador Senior',
  'Auxiliar Contable', 'Auxiliar Contable y Financiero', 'Asistente Contable',
  'Revisor Fiscal', 'Auditor', 'Auditor Interno', 'Auditor Externo',
  'Tesorero', 'Auxiliar de Tesorería', 'Analista de Cartera',
  'Cajero', 'Auxiliar de Caja', 'Facturador', 'Auxiliar de Facturación',
  'Auxiliar Financiero', 'Analista de Costos', 'Analista de Presupuesto',
  'Contador General Senior',

  // Talento humano
  'Profesional RRHH', 'Analista de Selección', 'Analista de Capacitación',
  'Analista de Compensación', 'Analista de Bienestar', 'Analista de Nómina',
  'Auxiliar de Nómina', 'Auxiliar de Selección', 'Auxiliar de RRHH',
  'Psicólogo Organizacional', 'Psicólogo de Selección', 'Trabajador Social',
  'Médico Ocupacional', 'Enfermero Ocupacional', 'Jefe de SST',
  'Analista SST', 'Auxiliar SST', 'Coordinador SST', 'Inspector SST',

  // Administración y oficina
  'Asistente Administrativo', 'Asistente Ejecutivo', 'Asistente de Gerencia',
  'Auxiliar Administrativo', 'Recepcionista', 'Telefonista', 'Mensajero',
  'Conductor', 'Conductor Ejecutivo', 'Oficios Generales',
  'Servicios Generales', 'Aseador', 'Vigilante', 'Portero',

  // Ventas y comercial
  'Ejecutivo de Ventas', 'Ejecutivo Comercial', 'Asesor Comercial',
  'Asesor de Ventas', 'Vendedor', 'Vendedor Tienda', 'Vendedor Mostrador',
  'Representante de Ventas', 'Representante Comercial', 'Agente Comercial',
  'Ejecutivo de Cuenta', 'KAM (Key Account Manager)', 'Teleoperador',
  'Asesor de Call Center', 'Agente de Servicio al Cliente',

  // Marketing
  'Director de Marketing', 'Jefe de Marketing', 'Community Manager',
  'Diseñador Publicitario', 'Copywriter', 'Analista de Marketing',
  'Coordinador de Marketing', 'Patrocinador', 'Brand Manager',

  // Operaciones y producción
  'Jefe de Producción', 'Operario de Producción', 'Operario de Manufactura',
  'Operario de Línea', 'Operario de Máquinas', 'Operario de Empaque',
  'Supervisor de Producción', 'Supervisor de Planta', 'Supervisor de Operaciones',
  'Almacenista', 'Auxiliar de Almacén', 'Jefe de Almacén', 'Bodeguero',
  'Conductor de Carga', 'Auxiliar de Despachos', 'Mensajero de Paquetes',

  // Logística y transporte
  'Coordinador Logístico', 'Jefe de Logística', 'Auxiliar de Logística',
  'Coordinador de Transporte', 'Despachador', 'Coordinador de Inventarios',
  'Auxiliar de Inventarios',

  // Compras
  'Jefe de Compras', 'Coordinador de Compras', 'Analista de Compras',
  'Auxiliar de Compras', 'Comprador', 'Comprador Junior', 'Comprador Senior',

  // Educación
  'Director Académico', 'Coordinador Académico', 'Rector', 'Coordinador de Programa',
  'Docente', 'Profesor', 'Tutor', 'Capacitador', 'Instructor',
  'Auxiliar Académico', 'Docente Universitario', 'Profesor Universitario',

  // Salud
  'Médico General', 'Médico Especialista', 'Enfermero', 'Auxiliar de Enfermería',
  'Odontólogo', 'Psicólogo Clínico', 'Fisioterapeuta', 'Nutricionista',
  'Farmacéutico', 'Médico Internista', 'Médico Pediatra', 'Médico Cirujano',

  // Legal
  'Abogado', 'Asesor Jurídico', 'Auxiliar Jurídico', 'Notificador',

  // Mantenimiento
  'Jefe de Mantenimiento', 'Técnico de Mantenimiento', 'Auxiliar de Mantenimiento',
  'Electricista', 'Plomero', 'Mecánico', 'Técnico Mecánico',
  'Técnico Eléctrico', 'Técnico en Refrigeración',

  // Servicios
  'Mesero', 'Cocinero', 'Auxiliar de Cocina', 'Bartender', 'Recepcionista de Hotel',
  'Camarera', 'Portero de Hotel', 'Guía Turístico',

  // Practicantes y aprendices
  'Practicante', 'Aprendiz SENA', 'Practicante Universitario',
  'Pasante', 'Trainee', 'Joven Profesional',

  // Salud (ampliado)
  'Médico Internista', 'Médico Cardiólogo', 'Médico Pediatra', 'Médico Ginecólogo',
  'Médico Cirujano', 'Médico Anestesiólogo', 'Médico Radiólogo', 'Médico Dermatólogo',
  'Médico Oftalmólogo', 'Médico Otorrinolaringólogo', 'Médico Neurólogo',
  'Médico Psiquiatra', 'Médico Ortopedista', 'Médico Urólogo', 'Médico Endocrinólogo',
  'Médico Gastroenterólogo', 'Médico Neumólogo', 'Médico Cardiólogo Infantil',
  'Médico del Trabajo', 'Médico Epidemiólogo', 'Médico Forense',
  'Enfermero Jefe', 'Enfermero Auxiliar', 'Auxiliar de Enfermería',
  'Instrumentador Quirúrgico', 'Regente de Farmacia', 'Auxiliar de Farmacia',
  'Fisioterapeuta', 'Terapeuta Respiratorio', 'Terapeuta Ocupacional',
  'Fonoaudiólogo', 'Optómetra', 'Bacteriólogo', 'Microbiólogo',
  'Biólogo', 'Bacteriólogo Clínico', 'Citohistotecnólogo',
  'Auxiliar de Laboratorio', 'Técnico de Radiología', 'Técnico en Imágenes Diagnósticas',
  'Higienista Oral', 'Auxiliar de Odontología', 'Ortodoncista', 'Endodoncista',
  'Nutricionista Clínico', 'Dietista', 'Psicólogo Clínico', 'Terapeuta Familiar',
  'Terapeuta Ocupacional', 'Fonoaudiólogo', 'Musicoterapeuta',

  // Educación (ampliado)
  'Rector', 'Vicerrector', 'Decano', 'Coordinador Académico',
  'Director de Colegio', 'Director de Jardín', 'Coordinador de Convivencia',
  'Docente de Aula', 'Docente de Apoyo', 'Docente Orientador',
  'Tutor de Virtualidad', 'Diseñador Instruccional', 'Coordinador de Prácticas',
  'Psicorientador', 'Bibliotecólogo', 'Auxiliar de Biblioteca',
  'Auxiliar de Investigación', 'Investigador', 'Investigador Junior',
  'Investigador Senior', 'Asistente de Investigación',

  // Legal (ampliado)
  'Abogado Senior', 'Abogado Junior', 'Pasante de Derecho',
  'Notario', 'Asistente Notarial', 'Procurador Judicial',
  'Defensor de Familia', 'Juez (Asistente)', 'Secretario Judicial',
  'Asesor Legal Externo', 'Consultor Jurídico', 'Perito Forense',
  'Investigador Privado', 'Agente de Propiedad Intelectual',
  'Analista de Cumplimiento', 'Oficial de Cumplimiento',

  // Arquitectura y construcción
  'Arquitecto Residencial', 'Arquitecto Comercial', 'Arquitecto Industrial',
  'Arquitecto de Interiores', 'Arquitecto Paisajista', 'Arquitecto Urbanista',
  'Ingeniero Residente de Obra', 'Ingeniero de Costos', 'Ingeniero Estructural',
  'Ingeniero Geotécnico', 'Ingeniero Hidráulico', 'Ingeniero de Tránsito',
  'Ingeniero de Pavimentos', 'Ingeniero de Cimentaciones', 'Ingeniero de Soldadura',
  'Maestro de Obra', 'Oficial de Construcción', 'Albañil', 'Encofrador',
  'Carpintero', 'Electricista de Obra', 'Plomero', 'Pintor de Obra',
  'Topógrafo', 'Cadista', 'Modelador BIM', 'Inspector de Obra',
  'Supervisor de Obra', 'Jefe de Residentes', 'Perito Valuador',

  // Transporte y logística
  'Conductor de Tractomula', 'Conductor de Camión', 'Conductor de Bus',
  'Conductor de Taxi', 'Conductor de Ambulancia', 'Conductor de Patineta',
  'Piloto de Avión', 'Auxiliar de Vuelo', 'Sobrecargo', 'Azafata',
  'Operador de Maquinaria Pesada', 'Operador de Grúa', 'Operador de Montacargas',
  'Despachador de Carga', 'Coordinador de Rutas', 'Analista de Tráfico',
  'Inspector de Tránsito', 'Recaudador de Peaje', 'Mensajero Motorizado',

  // Hostelería y turismo
  'Gerente de Hotel', 'Subgerente de Hotel', 'Jefe de Recepción',
  'Recepcionista de Hotel', 'Botones', 'Conserje', 'Valet Parking',
  'Jefe de Housekeeping', 'Camarera de Pisos', 'Mozo de Habitaciones',
  'Jefe de Mantenimiento Hotelero', 'Jefe de Alimentos y Bebidas',
  'Sommelier', 'Bartender', 'Barman', 'Capitán de Meseros',
  'Mesero', 'Hostess', 'Coordinador de Banquetes', 'Chef Ejecutivo',
  'Sous Chef', 'Chef de Partida', 'Cocinero', 'Pastelero', 'Panadero',
  'Ayudante de Cocina', 'Steward', 'Jefe de Compras Hoteleras',
  'Guía Turístico', 'Coordinador de Tours', 'Agente de Viajes',
  'Operador de Turismo de Aventura', 'Socorrista Acuático',

  // Industrial y manufactura
  'Operario de Producción', 'Operario de Ensamble', 'Operario de Empaque',
  'Operario de Soldadura', 'Soldador MIG/TIG', 'Soldador de Arco',
  'Tornero', 'Fresador', 'Rectificador', 'Mecánico Industrial',
  'Mecánico de Mantenimiento', 'Electricista Industrial',
  'Electromecánico', 'Instrumentista', 'Tubero', 'Calderero',
  'Operador de CNC', 'Programador de CNC', 'Operador de Torno',
  'Operador de Fresadora', 'Operador de Prensa', 'Operador de Inyectora',
  'Operador de Empacadora', 'Operador de Mezcladora', 'Operador de Horno',
  'Operador de Caldera', 'Operador de Montacargas',
  'Jefe de Turno', 'Jefe de Producción', 'Jefe de Mantenimiento',
  'Jefe de Calidad', 'Inspector de Calidad', 'Auditor de Calidad',
  'Analista de Procesos', 'Ingeniero de Procesos', 'Ingeniero de Manufactura',

  // Agroindustria
  'Ingeniero Agrónomo', 'Ingeniero Agrícola', 'Ingeniero Agroindustrial',
  'Técnico Agrícola', 'Operario de Campo', 'Tractorista',
  'Ingeniero Forestal', 'Técnico Forestal', 'Operario Forestal',
  'Veterinario', 'Técnico Veterinario', 'Auxiliar Veterinario',
  'Zootecnista', 'Inseminador', 'Veterinario de Granja',
  'Operario de Planta de Alimentos', 'Operario de Packing',
  'Inspector Sanitario', 'Analista de Laboratorio Agroindustrial',

  // Creativo y diseño
  'Director Creativo', 'Director de Arte', 'Diseñador Senior',
  'Diseñador Junior', 'Diseñador de Marca', 'Diseñador Editorial',
  'Diseñador de Empaque', 'Diseñador de Producto', 'Diseñador de Joyería',
  'Diseñador Textil', 'Diseñador de Modas Senior', 'Asistente de Diseño',
  'Ilustrador', 'Animador 2D', 'Animador 3D', 'Modelador 3D',
  'Editor de Video', 'Editor de Audio', 'Sonidista', 'Mezclador de Audio',
  'Productor Audiovisual', 'Director de Fotografía', 'Fotógrafo',
  'Asistente de Fotografía', 'Camarógrafo', 'Operador de Cámara',
  'Maquetador', 'Tipógrafo', 'Preprensista', 'Impresor Digital',
  'Operador de Plotter', 'Operador de Impresión Offset',
  'Redactor', 'Copywriter Creativo', 'Editor de Contenidos',
  'Content Manager', 'Community Manager Junior', 'Social Media Manager',

  // Gobierno y sector público
  'Servidor Público', 'Funcionario', 'Auxiliar Administrativo Público',
  'Inspector de Policía', 'Patrullero', 'Sargento', 'Teniente',
  'Capitán', 'Mayor', 'Coronel', 'Bombero', 'Paramédico',
  'Inspector de Tránsito Municipal', 'Inspector Sanitario',
  'Inspector de Obras Públicas', 'Notificador', 'Recaudador Municipal',
  'Tesorero Municipal', 'Contador Público', 'Auditor Fiscal',

  // Seguros y finanzas
  'Gerente de Seguros', 'Ejecutivo de Seguros', 'Asesor de Seguros',
  'Ajustador de Siniestros', 'Liquidador de Siniestros', 'Inspector de Riesgos',
  'Analista de Riesgos', 'Analista de Reaseguros', 'Suscriptor de Pólizas',
  'Agente de Seguros', 'Promotor de Seguros', 'Coordinador de Siniestros',
  'Jefe de Cobranza', 'Ejecutivo de Cobranza', 'Gestor de Cobranza',
  'Analista de Crédito', 'Analista de Cartera', 'Asesor Financiero',
  'Asesor de Inversiones', 'Banquero Privado', 'Gerente de Sucursal Bancaria',
  'Cajero Bancario', 'Atención al Cliente Bancario', 'Asesor Comercial Bancario',

  // Telecomunicaciones
  'Ingeniero de Telecomunicaciones', 'Técnico de Telecomunicaciones',
  'Instalador de Telecomunicaciones', 'Técnico de Fibra Óptica',
  'Técnico de Redes Celulares', 'Operador de Central Telefónica',
  'Ingeniero de Radiofrecuencia', 'Ingeniero de Antenas',
  'Técnico de Instalaciones', 'Coordinador de Fibra Óptica',
  'Supervisor de Campo', 'Técnico de Mantenimiento de Redes',

  // Servicios generales
  'Auxiliar de Servicios Generales', 'Jefe de Servicios Generales',
  'Mensajero Interno', 'Mensajero Externo', 'Repartidor',
  'Auxiliar de Mantenimiento', 'Jardinero', 'Pocero', 'Soldador de Mantenimiento',
  'Pintor', 'Yesero', 'Electricista Residencial', 'Plomero Residencial',
  'Cerrajero', 'Tapicero', 'Costurera', 'Modista', 'Sastre',
  'Zapatero', 'Relojero', 'Joyero', 'Optómetra', 'Fotógrafo de Tienda',

  // Investigación y academia
  'Investigador Científico', 'Asistente de Investigación',
  'Coordinador de Investigación', 'Director de Laboratorio',
  'Técnico de Laboratorio', 'Auxiliar de Investigación',
  'Becario de Investigación', 'Investigador Visitante',
  'Coordinador Académico', 'Director de Tesis',

  // Eventos y entretenimiento
  'Coordinador de Eventos', 'Productor de Eventos', 'Organizador de Bodas',
  'Coordinador de Protocolo', 'Maestro de Ceremonias', 'Animador de Eventos',
  'Coordinador de Logística de Eventos', 'Coordinador de Escenografía',
  'Técnico de Sonido', 'Técnico de Iluminación', 'Rigging',
  'Operador de Cámara de Eventos', 'VJ', 'Músico', 'Cantante',
  'Bailarín', 'Actor', 'Presentador', 'Locutor', 'Animador',
  'Coordinador de Actividades Recreativas', 'Monitor de Tiempo Libre',

  // ── IT / SISTEMAS AMPLIADO (roles modernos)

  // Cloud / DevOps / SRE
  'Site Reliability Engineer (SRE)', 'Platform Engineer', 'Cloud Native Engineer',
  'Kubernetes Administrator', 'AWS Solutions Architect', 'AWS Developer',
  'Azure Administrator', 'Azure Developer', 'GCP Engineer',
  'Cloud Security Engineer', 'Cloud Migration Specialist', 'Multi-Cloud Engineer',
  'Kubernetes Engineer', 'Docker Specialist', 'Helm Chart Developer',
  'Terraform Engineer', 'Ansible Automation Engineer', 'Jenkins Engineer',
  'GitLab CI/CD Engineer', 'GitHub Actions Engineer', 'CircleCI Specialist',
  'Observability Engineer', 'SRE Manager', 'Platform Engineering Lead',
  'Infrastructure as Code Engineer', 'Linux System Administrator',
  'Windows Server Administrator', 'Active Directory Administrator',
  'VMware Administrator', 'Citrix Administrator', 'Storage Engineer',
  'Backup Administrator', 'Disaster Recovery Specialist',

  // Seguridad / Ciberseguridad
  'Cybersecurity Analyst', 'Cybersecurity Engineer', 'Ethical Hacker',
  'Penetration Tester', 'Security Engineer', 'SOC Analyst (Tier 1)',
  'SOC Analyst (Tier 2)', 'SOC Analyst (Tier 3)', 'SOC Manager',
  'Information Security Manager', 'CISO (Chief Information Security Officer)',
  'Security Architect', 'Security Consultant', 'GRC Analyst',
  'Compliance Analyst', 'GDPR Specialist', 'HIPAA Compliance Officer',
  'PCI DSS Specialist', 'ISO 27001 Lead Auditor', 'Forensic Analyst',
  'Malware Analyst', 'Threat Intelligence Analyst', 'Red Team Specialist',
  'Blue Team Specialist', 'Purple Team Engineer', 'OSCP Certified Engineer',
  'DevSecOps Engineer', 'Application Security Engineer', 'Cloud Security Specialist',
  'Identity and Access Management (IAM) Engineer', 'Zero Trust Architect',
  'Cryptography Specialist', 'Blockchain Security Auditor',

  // Datos / IA / ML
  'DataOps Engineer', 'MLOps Engineer', 'ML Engineer', 'AI Engineer',
  'Prompt Engineer', 'LLM Engineer', 'Analytics Engineer',
  'Business Intelligence Developer', 'BI Analyst', 'BI Developer',
  'DataOps Specialist', 'Feature Store Engineer', 'ML Platform Engineer',
  'Computer Vision Engineer', 'NLP Engineer', 'Speech Recognition Engineer',
  'Recommender Systems Engineer', 'Reinforcement Learning Engineer',
  'ML Research Engineer', 'AI Research Scientist', 'Data Product Manager',
  'Data Steward', 'Data Governance Specialist', 'Data Architect',
  'Data Modeler', 'ETL Developer', 'Data Pipeline Engineer',
  'Streaming Data Engineer', 'Spark Developer', 'Hadoop Developer',
  'Snowflake Engineer', 'Databricks Engineer', 'Big Data Engineer',
  'Data Visualization Specialist', 'Tableau Developer', 'Power BI Developer',
  'Looker Developer', 'dbt Developer', 'Airflow Engineer',
  'ML Infrastructure Engineer', 'Model Deployment Engineer',
  'Responsible AI Specialist', 'AI Ethics Specialist', 'AI Product Manager',

  // Blockchain / Web3
  'Blockchain Developer', 'Smart Contract Developer', 'Solidity Developer',
  'Web3 Engineer', 'DeFi Engineer', 'NFT Engineer', 'Crypto Engineer',
  'Blockchain Architect', 'Consensus Protocol Engineer', 'Cryptographer',
  'Web3 Frontend Developer', 'Web3 Backend Engineer', 'IPFS Engineer',
  'Ethereum Developer', 'Hyperledger Developer', 'Polygon Developer',
  'Solana Developer', 'Cosmos SDK Developer', 'Substrate Developer',
  'Tokenomics Specialist', 'DAO Specialist', 'NFT Marketplace Developer',
  'DeFi Protocol Engineer', 'Layer 2 Developer', 'Zero-Knowledge Engineer',
  'Rollup Engineer', 'Bridge Developer', 'MEV Searcher',
  'Solidity Auditor', 'Blockchain Security Researcher', 'Chainlink Developer',

  // Mobile
  'iOS Developer', 'Android Developer', 'React Native Developer',
  'Flutter Developer', 'Xamarin Developer', 'Ionic Developer', 'Cordova Developer',
  'Swift Developer', 'SwiftUI Developer', 'Kotlin Developer',
  'Objective-C Developer', 'Java Developer (Mobile)', 'Dart Developer',
  'Mobile Lead', 'Mobile Architect', 'iOS Tech Lead', 'Android Tech Lead',
  'Mobile QA Engineer', 'Mobile DevOps Engineer', 'App Store Optimization (ASO) Specialist',
  'Mobile Product Manager', 'Mobile UX Designer', 'WatchOS Developer',
  'tvOS Developer', 'Android TV Developer', 'Wear OS Developer',

  // Frontend moderno
  'Vue.js Developer', 'Vue 3 Developer', 'Nuxt.js Developer',
  'Svelte Developer', 'SvelteKit Developer', 'React Developer',
  'Next.js Developer', 'Remix Developer', 'Astro Developer',
  'Solid.js Developer', 'Qwik Developer', 'HTMX Developer',
  'Angular Developer', 'AngularJS Developer', 'Ember.js Developer',
  'TypeScript Developer', 'JavaScript Developer', 'Web Components Developer',
  'CSS Specialist', 'Tailwind CSS Specialist', 'CSS-in-JS Engineer',
  'Webpack Specialist', 'Vite Specialist', 'Rollup Specialist',
  'Module Federation Specialist', 'Micro-frontend Architect',
  'Web Components Specialist', 'PWA Developer', 'WebAssembly Developer',
  'WebGL Developer', 'Three.js Developer', 'Babylon.js Developer',
  'D3.js Developer', 'Chart.js Developer', 'Mapbox Developer',
  'Animation Engineer', 'Framer Motion Developer', 'GSAP Developer',

  // Backend
  'Node.js Developer', 'Deno Developer', 'Bun Developer', 'Go Developer',
  'Golang Developer', 'Rust Developer', 'Elixir Developer', 'Phoenix Developer',
  'Erlang Developer', 'C# Developer', '.NET Developer', 'ASP.NET Developer',
  'Java Developer', 'Spring Boot Developer', 'Kotlin Backend Developer',
  'Python Developer', 'Django Developer', 'Flask Developer', 'FastAPI Developer',
  'Ruby Developer', 'Ruby on Rails Developer', 'PHP Developer', 'Laravel Developer',
  'Symfony Developer', 'Scala Developer', 'Clojure Developer', 'Haskell Developer',
  'Perl Developer', 'C++ Developer', 'C Developer', 'Embedded C Developer',
  'GraphQL Engineer', 'REST API Designer', 'API Architect',
  'Backend Tech Lead', 'Microservices Architect', 'Service Mesh Engineer',
  'gRPC Specialist', 'Apache Kafka Engineer', 'RabbitMQ Engineer',
  'Redis Specialist', 'PostgreSQL Expert', 'MySQL DBA', 'MongoDB Engineer',
  'Cassandra Engineer', 'DynamoDB Expert', 'Elasticsearch Engineer',
  'ClickHouse Engineer', 'Snowflake Engineer', 'BigQuery Expert',

  // RPA / Low-Code
  'RPA Developer', 'UiPath Developer', 'Blue Prism Developer',
  'Automation Anywhere Developer', 'Power Automate Developer',
  'Low-Code Developer', 'OutSystems Developer', 'Mendix Developer',
  'Appian Developer', 'Bubble Developer', 'Retool Developer',
  'Make.com Specialist', 'Zapier Specialist', 'n8n Developer',
  'Workflow Automation Specialist', 'Process Automation Engineer',

  // DevRel / Developer Experience
  'DevRel Engineer', 'Developer Advocate', 'Developer Experience Engineer',
  'Technical Evangelist', 'Community Manager (Tech)', 'Open Source Programmer',
  'Developer Relations Manager', 'Technical Writer', 'Documentation Engineer',
  'API Documentation Specialist', 'SDK Engineer', 'Open Source Maintainer',
  'Hackathon Organizer', 'Conference Speaker', 'Technical Trainer',
  'Engineering Educator', 'Bootcamp Instructor', 'Code Reviewer',

  // Liderazgo técnico / Management
  'CTO (Chief Technology Officer)', 'CIO (Chief Information Officer)',
  'VP of Engineering', 'VP of Technology', 'Director de Tecnología',
  'Director de Ingeniería', 'Director de TI', 'IT Manager',
  'Engineering Manager', 'Senior Engineering Manager', 'Director of Engineering',
  'Group Engineering Manager', 'Principal Engineer', 'Staff Engineer',
  'Distinguished Engineer', 'Fellow Engineer', 'Technical Director',
  'Head of Engineering', 'Head of Technology', 'VP of Product',
  'Service Desk Manager', 'IT Operations Manager', 'Infrastructure Manager',
  'DevOps Manager', 'Security Manager', 'Data Manager',
  'Engineering Program Manager', 'Technical Program Manager',

  // QA / Testing
  'QA Engineer', 'QA Lead', 'QA Manager', 'SDET (Software Development Engineer in Test)',
  'Test Automation Engineer', 'Performance Test Engineer', 'Load Test Engineer',
  'Security Test Engineer', 'Penetration Tester', 'Accessibility Tester',
  'Mobile Test Engineer', 'API Test Engineer', 'Performance Engineer',
  'Chaos Engineer', 'Reliability Engineer', 'Test Architect',
  'QA Analyst', 'QA Consultant', 'Test Lead', 'Automation Architect',
  'Selenium Specialist', 'Cypress Developer', 'Playwright Developer',
  'JUnit Specialist', 'Pytest Developer', 'Postman Specialist',

  // Embedded / IoT / Hardware
  'Embedded Systems Engineer', 'Embedded Software Engineer', 'Firmware Engineer',
  'IoT Engineer', 'IoT Solutions Architect', 'IoT Developer',
  'Edge Computing Specialist', 'RTOS Engineer', 'Microcontroller Programmer',
  'FPGA Engineer', 'ASIC Design Engineer', 'PCB Designer',
  'Hardware Engineer', 'Hardware Design Engineer', 'Embedded Linux Engineer',
  'Yocto Project Developer', 'Buildroot Engineer', 'Device Driver Developer',
  'Robotics Engineer', 'Robotics Software Engineer', 'ROS Developer',
  'Drone Engineer', 'UAV Software Engineer', 'Autonomous Systems Engineer',
  'AR/VR Developer', 'Mixed Reality Developer', 'Spatial Computing Developer',
  'Unity Developer', 'Unreal Engine Developer', 'Game Developer',
  'Game Engine Programmer', 'Graphics Programmer', 'Shader Programmer',
  'Computer Graphics Engineer', 'Game Physics Programmer', 'AI Behavior Programmer',
  'Game Designer', 'Level Designer', 'Narrative Designer',

  // ERP / CRM / Business Systems
  'SAP Consultant', 'SAP ABAP Developer', 'SAP Fiori Developer',
  'SAP HANA Consultant', 'SAP MM Consultant', 'SAP FI Consultant',
  'SAP SD Consultant', 'SAP PP Consultant', 'SAP BW Consultant',
  'SAP Basis Administrator', 'Salesforce Developer', 'Salesforce Administrator',
  'Salesforce Architect', 'Oracle DBA', 'Oracle Developer', 'Oracle APEX Developer',
  'SQL Server DBA', 'MySQL DBA', 'PostgreSQL DBA', 'MongoDB Administrator',
  'ERP Consultant', 'CRM Consultant', 'Workday Consultant', 'SAP SuccessFactors Consultant',
  'ServiceNow Developer', 'ServiceNow Administrator', 'Power Platform Developer',
  'Dynamics 365 Consultant', 'SharePoint Administrator', 'SharePoint Developer',
  'Odoo Developer', 'NetSuite Consultant',

  // Auxiliares de IT
  'Auxiliar de Sistemas', 'Auxiliar de Soporte Técnico', 'Pasante de TI',
  'Técnico de Soporte', 'Help Desk Analyst', 'Service Desk Analyst',
  'IT Support Specialist', 'IT Support Engineer', 'IT Technician',
  'Field Service Technician', 'Deskside Support Technician', 'IT Asset Coordinator',

  // Otros IT modernos
  'Solutions Architect', 'Enterprise Architect', 'Cloud Architect',
  'Integration Engineer', 'Middleware Engineer', 'API Gateway Engineer',
  'ServiceNow Architect', 'Salesforce Architect', 'Workday Integration Consultant',
  'Microsoft 365 Administrator', 'Exchange Administrator', 'SharePoint Online Administrator',
  'Active Directory Engineer', 'Identity Management Specialist',
  'PKI Engineer', 'Single Sign-On (SSO) Engineer', 'Federation Specialist',
  'OAuth Specialist', 'SAML Specialist', 'API Management Specialist',
  'Streaming Engineer', 'WebRTC Developer', 'Socket.io Developer',
  'GraphQL Federation Engineer', 'tRPC Developer', 'Prisma Specialist',
  'TypeORM Developer', 'Sequelize Developer', 'Drizzle ORM Developer',
  'Hasura Engineer', 'Supabase Developer', 'Firebase Developer',
  'AWS Lambda Engineer', 'Azure Functions Developer', 'Cloudflare Workers Developer',
  'Vercel Engineer', 'Netlify Engineer', 'Vercel Edge Functions Developer',
  'Cloudflare Workers Specialist', 'Deno Deploy Developer', 'Fly.io Developer',
  'NoSQL Specialist', 'Graph Database Engineer', 'Time Series Database Engineer',
  'InfluxDB Engineer', 'TimescaleDB Engineer', 'QuestDB Engineer',
  'Event Sourcing Architect', 'CQRS Specialist', 'Saga Pattern Specialist',
  'Distributed Systems Engineer', 'Consensus Algorithm Engineer',
  'Raft Consensus Specialist', 'Paxos Specialist', 'Byzantine Fault Tolerance Engineer',
  'Technical Product Manager', 'API Product Manager', 'Platform Product Manager',
  'Developer Experience Manager', 'Engineering Productivity Manager',
  'Staff+ Engineer', 'Principal Software Engineer', 'Distinguished Engineer',
]

// ── Programas académicos colombianos
//    Nivel: 'Profesional' | 'Tecnólogo' | 'Técnico' | 'Auxiliar'
export const PROGRAMAS_ACADEMICOS = [
  // Profesionales universitarios
  { nombre: 'Administración de Empresas', nivel: 'Profesional' },
  { nombre: 'Administración en Salud', nivel: 'Profesional' },
  { nombre: 'Administración Financiera', nivel: 'Profesional' },
  { nombre: 'Administración Pública', nivel: 'Profesional' },
  { nombre: 'Administración de Empresas Turísticas y Hoteleras', nivel: 'Profesional' },
  { nombre: 'Administración Agropecuaria', nivel: 'Profesional' },
  { nombre: 'Antropología', nivel: 'Profesional' },
  { nombre: 'Arquitectura', nivel: 'Profesional' },
  { nombre: 'Artes Visuales', nivel: 'Profesional' },
  { nombre: 'Artes Plásticas', nivel: 'Profesional' },
  { nombre: 'Artes Escénicas', nivel: 'Profesional' },
  { nombre: 'Biología', nivel: 'Profesional' },
  { nombre: 'Bioquímica', nivel: 'Profesional' },
  { nombre: 'Ciencia Política', nivel: 'Profesional' },
  { nombre: 'Ciencias Sociales', nivel: 'Profesional' },
  { nombre: 'Comunicación Social', nivel: 'Profesional' },
  { nombre: 'Comunicación Social y Periodismo', nivel: 'Profesional' },
  { nombre: 'Comunicación Audiovisual', nivel: 'Profesional' },
  { nombre: 'Contaduría Pública', nivel: 'Profesional' },
  { nombre: 'Derecho', nivel: 'Profesional' },
  { nombre: 'Diseño Gráfico', nivel: 'Profesional' },
  { nombre: 'Diseño Industrial', nivel: 'Profesional' },
  { nombre: 'Diseño de Modas', nivel: 'Profesional' },
  { nombre: 'Diseño Visual', nivel: 'Profesional' },
  { nombre: 'Economía', nivel: 'Profesional' },
  { nombre: 'Enfermería', nivel: 'Profesional' },
  { nombre: 'Español y Literatura', nivel: 'Profesional' },
  { nombre: 'Estadística', nivel: 'Profesional' },
  { nombre: 'Farmacia', nivel: 'Profesional' },
  { nombre: 'Filosofía', nivel: 'Profesional' },
  { nombre: 'Física', nivel: 'Profesional' },
  { nombre: 'Fisioterapia', nivel: 'Profesional' },
  { nombre: 'Geografía', nivel: 'Profesional' },
  { nombre: 'Geología', nivel: 'Profesional' },
  { nombre: 'Historia', nivel: 'Profesional' },
  { nombre: 'Ingeniería Aeronáutica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Agrícola', nivel: 'Profesional' },
  { nombre: 'Ingeniería Ambiental', nivel: 'Profesional' },
  { nombre: 'Ingeniería Biomédica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Civil', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Alimentos', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Minas', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Petróleos', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Sistemas', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Sistemas y Computación', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Software', nivel: 'Profesional' },
  { nombre: 'Ingeniería Eléctrica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Electrónica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Electromecánica', nivel: 'Profesional' },
  { nombre: 'Ingeniería en Energía', nivel: 'Profesional' },
  { nombre: 'Ingeniería Financiera', nivel: 'Profesional' },
  { nombre: 'Ingeniería Forestal', nivel: 'Profesional' },
  { nombre: 'Ingeniería Geológica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Industrial', nivel: 'Profesional' },
  { nombre: 'Ingeniería Mecánica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Mecatrónica', nivel: 'Profesional' },
  { nombre: 'Ingeniería Naval', nivel: 'Profesional' },
  { nombre: 'Ingeniería Química', nivel: 'Profesional' },
  { nombre: 'Ingeniería Sanitaria', nivel: 'Profesional' },
  { nombre: 'Ingeniería de Telecomunicaciones', nivel: 'Profesional' },
  { nombre: 'Instrumentación Quirúrgica', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Artes', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Biología', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Ciencias Sociales', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Educación Física', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Educación Infantil', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Español e Inglés', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Matemáticas', nivel: 'Profesional' },
  { nombre: 'Licenciatura en Pedagogía', nivel: 'Profesional' },
  { nombre: 'Marketing', nivel: 'Profesional' },
  { nombre: 'Matemáticas', nivel: 'Profesional' },
  { nombre: 'Medicina', nivel: 'Profesional' },
  { nombre: 'Medicina Veterinaria', nivel: 'Profesional' },
  { nombre: 'Mercadeo y Publicidad', nivel: 'Profesional' },
  { nombre: 'Mercadeo Internacional', nivel: 'Profesional' },
  { nombre: 'Música', nivel: 'Profesional' },
  { nombre: 'Negocios Internacionales', nivel: 'Profesional' },
  { nombre: 'Nutrición y Dietética', nivel: 'Profesional' },
  { nombre: 'Odontología', nivel: 'Profesional' },
  { nombre: 'Optometría', nivel: 'Profesional' },
  { nombre: 'Pedagogía', nivel: 'Profesional' },
  { nombre: 'Periodismo', nivel: 'Profesional' },
  { nombre: 'Psicología', nivel: 'Profesional' },
  { nombre: 'Psicopedagogía', nivel: 'Profesional' },
  { nombre: 'Química', nivel: 'Profesional' },
  { nombre: 'Química Farmacéutica', nivel: 'Profesional' },
  { nombre: 'Relaciones Internacionales', nivel: 'Profesional' },
  { nombre: 'Sociología', nivel: 'Profesional' },
  { nombre: 'Teatro', nivel: 'Profesional' },
  { nombre: 'Trabajo Social', nivel: 'Profesional' },
  { nombre: 'Turismo', nivel: 'Profesional' },
  { nombre: 'Zootecnia', nivel: 'Profesional' },

  // Tecnólogos
  { nombre: 'Tecnología en Administración de Empresas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Administración Financiera', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Administración Agropecuaria', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Agrobiotecnología', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Análisis de Muestras Químicas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Análisis y Programación de Sistemas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Atención Prehospitalaria', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Automatización Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Banca y Finanzas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Biología Ambiental', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Biotecnología', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Calidad', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Cerámica', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Ciencias Ambientales', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Comercialización Internacional', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Comunicación Social', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Construcción', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Contabilidad y Finanzas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Contratación', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Control Ambiental', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Control de Calidad', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Coordinación de Eventos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Cosmetología', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Criminalística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Diseño de Modas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Diseño de Productos Industriales', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Diseño Gráfico', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Diseño Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Documentación y Archivística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Electricidad', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Electrónica', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Electromedicina', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Empresas Asociativas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Enfermería', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Estadística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Farmacia', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Finanzas y Negocios', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Administrativa', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Bancaria y Financiera', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Comercial y de Negocios', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Empresas Asociativas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Mercadeo', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Obras Civiles', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Producción Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Recursos Naturales', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión de Servicios Gastronómicos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión del Talento Humano', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Empresarial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Financiera y Presupuestal', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Hotelera y Turística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Judicial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Logística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Gestión Pública', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Horticultura', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Hotelería y Turismo', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Informática', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Informática Musical', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Instrumentación Electrónica', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Investigación Judicial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Logística', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento de Aeronaves', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Electrónico', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Electromecánico', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Electrónico Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Mecánico', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mantenimiento Mecatrónico de Automotores', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Manejo Ambiental', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Manejo de Recursos Naturales', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Marketing', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mecánica Automotriz', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mecánica Dental', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mecánica Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mecatrónica', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mercadeo y Publicidad', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Mercadeo y Ventas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Minería', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Movilidad y Seguridad Vial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Multimedia', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Navegación y Buceo', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Negociación Internacional', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Obras Civiles', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Operación de Aviones', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Operación de Plantas Petroquímicas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Operaciones de Comercio Exterior', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Operaciones Financieras', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Operaciones Turísticas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Organización de Eventos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Agropecuaria Ecológica', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Animal', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción de Televisión', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Forestal', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Pecuaria', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Producción Vegetal', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Productos Electrónicos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Programación de Sistemas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Promoción Social', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Publicidad', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Química Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Química Textil', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Radiología', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Realización Audiovisual', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Recursos Humanos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Redes de Computadores', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Regencia de Farmacia', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Saneamiento Ambiental', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Salud Ocupacional', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Seguridad e Higiene Ocupacional', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Sistemas', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Sistemas de Información', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Sistemas Embebidos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Sistemas Energéticos', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Soldadura', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Supervisión Industrial', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Telecomunicaciones', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Telemática', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Turismo', nivel: 'Tecnólogo' },
  { nombre: 'Tecnología en Veterinaria', nivel: 'Tecnólogo' },

  // Técnicos
  { nombre: 'Técnico en Administración de Empresas', nivel: 'Técnico' },
  { nombre: 'Técnico en Atención a la Primera Infancia', nivel: 'Técnico' },
  { nombre: 'Técnico en Atención al Cliente', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar Administrativo', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar Contable y Financiero', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar de Droguería', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar de Enfermería', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar de Farmacia', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar de Odontología', nivel: 'Técnico' },
  { nombre: 'Técnico en Auxiliar de Servicios Farmacéuticos', nivel: 'Técnico' },
  { nombre: 'Técnico en Banca y Servicios Financieros', nivel: 'Técnico' },
  { nombre: 'Técnico en Cajeros y Servicios Financieros', nivel: 'Técnico' },
  { nombre: 'Técnico en Carpintería', nivel: 'Técnico' },
  { nombre: 'Técnico en Cocina', nivel: 'Técnico' },
  { nombre: 'Técnico en Comercio Internacional', nivel: 'Técnico' },
  { nombre: 'Técnico en Computación', nivel: 'Técnico' },
  { nombre: 'Técnico en Confección Industrial', nivel: 'Técnico' },
  { nombre: 'Técnico en Construcción', nivel: 'Técnico' },
  { nombre: 'Técnico en Contabilidad', nivel: 'Técnico' },
  { nombre: 'Técnico en Contabilidad y Finanzas', nivel: 'Técnico' },
  { nombre: 'Técnico en Control de Calidad', nivel: 'Técnico' },
  { nombre: 'Técnico en Cosmetología', nivel: 'Técnico' },
  { nombre: 'Técnico en Culinaria', nivel: 'Técnico' },
  { nombre: 'Técnico en Diseño Gráfico', nivel: 'Técnico' },
  { nombre: 'Técnico en Electricidad', nivel: 'Técnico' },
  { nombre: 'Técnico en Electrónica', nivel: 'Técnico' },
  { nombre: 'Técnico en Enfermería', nivel: 'Técnico' },
  { nombre: 'Técnico en Estética Facial y Corporal', nivel: 'Técnico' },
  { nombre: 'Técnico en Farmacia', nivel: 'Técnico' },
  { nombre: 'Técnico en Gastronomía', nivel: 'Técnico' },
  { nombre: 'Técnico en Gestión Administrativa', nivel: 'Técnico' },
  { nombre: 'Técnico en Gestión Contable y Financiera', nivel: 'Técnico' },
  { nombre: 'Técnico en Gestión Documental', nivel: 'Técnico' },
  { nombre: 'Técnico en Gestión Empresarial', nivel: 'Técnico' },
  { nombre: 'Técnico en Gestión Logística', nivel: 'Técnico' },
  { nombre: 'Técnico en Higiene Oral', nivel: 'Técnico' },
  { nombre: 'Técnico en Hostelería y Turismo', nivel: 'Técnico' },
  { nombre: 'Técnico en Informática', nivel: 'Técnico' },
  { nombre: 'Técnico en Instalaciones Eléctricas', nivel: 'Técnico' },
  { nombre: 'Técnico en Instalaciones Hidráulicas y Sanitarias', nivel: 'Técnico' },
  { nombre: 'Técnico en Instrumentación Industrial', nivel: 'Técnico' },
  { nombre: 'Técnico en Laboratorio Clínico', nivel: 'Técnico' },
  { nombre: 'Técnico en Logística Empresarial', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento de Computadores', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento de Equipos de Cómputo', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento Eléctrico', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento Electrónico', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento Mecánico', nivel: 'Técnico' },
  { nombre: 'Técnico en Mantenimiento Mecatrónico', nivel: 'Técnico' },
  { nombre: 'Técnico en Mecánica Automotriz', nivel: 'Técnico' },
  { nombre: 'Técnico en Mecánica Dental', nivel: 'Técnico' },
  { nombre: 'Técnico en Mecánica Industrial', nivel: 'Técnico' },
  { nombre: 'Técnico en Mecatrónica', nivel: 'Técnico' },
  { nombre: 'Técnico en Mercadeo y Ventas', nivel: 'Técnico' },
  { nombre: 'Técnico en Minería', nivel: 'Técnico' },
  { nombre: 'Técnico en Operación de Equipos de Cómputo', nivel: 'Técnico' },
  { nombre: 'Técnico en Operación de Equipos Industriales', nivel: 'Técnico' },
  { nombre: 'Técnico en Operación de Maquinaria Pesada', nivel: 'Técnico' },
  { nombre: 'Técnico en Panadería y Pastelería', nivel: 'Técnico' },
  { nombre: 'Técnico en Peluquería', nivel: 'Técnico' },
  { nombre: 'Técnico en Pintura Industrial', nivel: 'Técnico' },
  { nombre: 'Técnico en Preprensa Digital', nivel: 'Técnico' },
  { nombre: 'Técnico en Producción de Televisión', nivel: 'Técnico' },
  { nombre: 'Técnico en Producción Pecuaria', nivel: 'Técnico' },
  { nombre: 'Técnico en Programación de Computadores', nivel: 'Técnico' },
  { nombre: 'Técnico en Promoción de la Salud', nivel: 'Técnico' },
  { nombre: 'Técnico en Recursos Humanos', nivel: 'Técnico' },
  { nombre: 'Técnico en Refrigeración y Climatización', nivel: 'Técnico' },
  { nombre: 'Técnico en Reparación de Electrodomésticos', nivel: 'Técnico' },
  { nombre: 'Técnico en Salud Oral', nivel: 'Técnico' },
  { nombre: 'Técnico en Saneamiento Ambiental', nivel: 'Técnico' },
  { nombre: 'Técnico en Secretariado', nivel: 'Técnico' },
  { nombre: 'Técnico en Seguros', nivel: 'Técnico' },
  { nombre: 'Técnico en Servicios de Alimentación', nivel: 'Técnico' },
  { nombre: 'Técnico en Servicios de Salud', nivel: 'Técnico' },
  { nombre: 'Técnico en Sistemas', nivel: 'Técnico' },
  { nombre: 'Técnico en Soldadura', nivel: 'Técnico' },
  { nombre: 'Técnico en Soldadura Eléctrica', nivel: 'Técnico' },
  { nombre: 'Técnico en Telecomunicaciones', nivel: 'Técnico' },
  { nombre: 'Técnico en Trabajo Social', nivel: 'Técnico' },
  { nombre: 'Técnico en Turismo', nivel: 'Técnico' },
  { nombre: 'Técnico Judicial', nivel: 'Técnico' },
]

export const AREAS_LABORALES = [
  'Administración y Oficina',
  'Tecnología y Sistemas',
  'Finanzas y Contabilidad',
  'Talento Humano',
  'Marketing y Ventas',
  'Operaciones y Logística',
  'Producción y Manufactura',
  'Calidad',
  'Servicio al Cliente',
  'Legal y Jurídico',
  'Compras y Adquisiciones',
  'Investigación y Desarrollo',
  'Diseño y Creatividad',
  'Educación y Docencia',
  'Salud y Medicina',
  'Ingeniería',
  'Construcción',
  'Mantenimiento',
  'Seguridad y Salud en el Trabajo',
  'Auditoría y Control',
  'Comercio Exterior',
  'Mercadeo y Publicidad',
  'Comunicaciones',
  'Arquitectura y Diseño',
  'Logística y Transporte',
  'Hotelería y Turismo',
  'Gastronomía y Cocina',
  'Agricultura y Ganadería',
  'Minería y Energía',
  'Medio Ambiente',
]

// ── Agrupar cargos alfabéticamente (A, B, C, ... 0-9) para usar con Dropdown
//     PrimeReact consume `{ label, items: [{label,value}] }` con optionGroupLabel/Children
//     Deduplicamos antes para evitar keys duplicadas que rompan el render.
function _dedupe(list) {
  const seen = new Set()
  const out = []
  for (const item of list) {
    const key = typeof item === 'string' ? item : item?.nombre
    if (!seen.has(key)) {
      seen.add(key)
      out.push(item)
    }
  }
  return out
}

function _groupByLetter(items, labelFn = (s) => s) {
  const buckets = {}
  for (const item of items) {
    const raw = labelFn(item).trim()
    const ch = raw[0] || '#'
    const key = /[A-Za-zÁÉÍÓÚáéíóúÑñ]/.test(ch) ? ch.toUpperCase() : '#'
    if (!buckets[key]) buckets[key] = []
    buckets[key].push(item)
  }
  return Object.keys(buckets)
    .sort()
    .map((key) => ({
      label: key,
      code: key.toLowerCase(),
      items: buckets[key].map((i) => ({ label: i, value: i })),
    }))
}

export function cargosToDropdownGroups() {
  return _groupByLetter(_dedupe(CARGOS))
}

export function programasToDropdownGroups() {
  const niveles = ['Profesional', 'Tecnólogo', 'Técnico', 'Auxiliar']
  const deduped = _dedupe(PROGRAMAS_ACADEMICOS)
  return niveles
    .map((nivel) => {
      const items = deduped.filter((p) => p.nivel === nivel)
      if (!items.length) return null
      return {
        label: `${nivel} · ${items.length}`,
        code: nivel.toLowerCase(),
        items: items.map((i) => ({ label: i.nombre, value: i.nombre })),
      }
    })
    .filter(Boolean)
}

/* ════════════════════════════════════════════════════════════════
   Enriquecimiento de CARGOS y PROGRAMAS_ACADEMICOS para los popovers
   ════════════════════════════════════════════════════════════════ */
const NIVEL_COLOR_MAP = {
  'Profesional':   'emerald',
  'Tecnólogo':      'cyan',
  'Técnico':        'amber',
  'Auxiliar':       'slate',
  'Directivo':      'rose',
  'Subdirección':   'rose',
  'Jefatura':       'violet',
  'Profesional Senior': 'brand',
  'Senior':         'brand',
  'Junior':         'slate',
  'Operativo':      'amber',
  'General':        'slate',
}

function classifyCargo(name) {
  const lower = name.toLowerCase()
  if (lower.includes('director general') || lower.includes('director ejecutivo') || lower.includes('gerente general')) {
    return { nivel: 'Directivo', area: 'Alta dirección' }
  }
  if (lower.includes('director') || lower.includes('gerente')) {
    return { nivel: 'Directivo', area: 'Dirección' }
  }
  if (lower.startsWith('subgerente') || lower.startsWith('subdirector') || lower.includes('vicepresidente')) {
    return { nivel: 'Subdirección', area: 'Dirección' }
  }
  if (lower.startsWith('jefe') || lower.startsWith('coord')) {
    return { nivel: 'Jefatura', area: 'Coordinación' }
  }
  if (lower.includes('senior') || /\bsr\.?\b/.test(lower)) {
    return { nivel: 'Profesional Senior', area: 'Profesional' }
  }
  if (lower.includes('analista') || lower.includes('especialista') || lower.includes('consultor')) {
    return { nivel: 'Profesional', area: 'Análisis' }
  }
  if (lower.includes('ingeniero') || lower.includes('arquitecto') || lower.includes('diseñador')) {
    return { nivel: 'Profesional', area: 'Técnica' }
  }
  if (lower.includes('desarrollador') || lower.includes('programador') || lower.includes('engineer') || lower.includes('dev ')) {
    return { nivel: 'Profesional', area: 'Tecnología' }
  }
  if (lower.includes('docente') || lower.includes('profesor') || lower.includes('maestro')) {
    return { nivel: 'Profesional', area: 'Educación' }
  }
  if (lower.includes('medic') || lower.includes('enferm') || lower.includes('psicólog') || lower.includes('odont')) {
    return { nivel: 'Profesional', area: 'Salud' }
  }
  if (lower.includes('abogad') || lower.includes('contador') || lower.includes('auditor')) {
    return { nivel: 'Profesional', area: 'Legal/Finanzas' }
  }
  if (lower.includes('operario') || lower.includes('operador')) {
    return { nivel: 'Operativo', area: 'Producción' }
  }
  if (lower.includes('técnico') || lower.includes('tecnico') || lower.includes('técnologo')) {
    return { nivel: 'Técnico', area: 'Operativa' }
  }
  if (lower.includes('auxiliar') || lower.includes('asistente') || lower.includes('practicante') || lower.includes('pasante') || lower.includes('aprendiz') || lower.includes('junior') || lower.includes('jr.')) {
    return { nivel: 'Junior', area: 'Soporte' }
  }
  return { nivel: 'Profesional', area: 'General' }
}

function getInitials(name = '') {
  return name
    .split(/[\s/]+/)
    .filter(Boolean)
    .slice(0, 3)
    .map((w) => w[0]?.toUpperCase() || '')
    .join('')
    .slice(0, 2)
}

const DURACION_TIPICA = {
  Profesional: '~5 años',
  'Profesional Senior': '~5 años + exp.',
  Tecnólogo: '~3 años',
  Técnico: '~2 años',
  Auxiliar: '~6 meses',
}

/* Cargos enriquecidos: { label, value, initials, nivel, area } */
export const CARGOS_ENRIQUECIDOS = CARGOS.map((label) => ({
  label,
  value: label,
  initials: getInitials(label),
  ...classifyCargo(label),
}))

/* Programas académicos enriquecidos: { label, value, initials, nivel } */
export const PROGRAMAS_ENRIQUECIDOS = PROGRAMAS_ACADEMICOS.map((p) => ({
  label: p.nombre,
  value: p.nombre,
  initials: getInitials(p.nombre),
  nivel: p.nivel,
  duracion: DURACION_TIPICA[p.nivel] || 'Variable',
  area: 'Educación',
}))

